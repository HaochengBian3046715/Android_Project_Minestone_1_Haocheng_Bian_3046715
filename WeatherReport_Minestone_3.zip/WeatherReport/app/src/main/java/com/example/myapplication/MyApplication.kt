package com.example.myapplication

import android.app.Application
import com.example.myapplication.util.DarkModeUtils

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        sInstance = this
        DarkModeUtils.init(this)
    }

    companion object {
        var sInstance: MyApplication? = null
    }
}