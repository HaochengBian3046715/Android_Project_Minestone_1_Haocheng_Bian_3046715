package com.example.myapplication

import android.app.Application

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        sInstance = this
    }

    companion object {
        var sInstance: MyApplication? = null
    }
}