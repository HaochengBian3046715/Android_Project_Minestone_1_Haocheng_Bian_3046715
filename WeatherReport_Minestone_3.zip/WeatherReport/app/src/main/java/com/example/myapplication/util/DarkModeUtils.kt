package com.example.myapplication.util

import android.app.Application
import android.content.Context
import com.example.myapplication.util.DarkModeUtils
import androidx.appcompat.app.AppCompatDelegate
import android.content.SharedPreferences
import android.content.res.Configuration

/**
 * Dark Mode adaptation tools
 */
object DarkModeUtils {
    const val KEY_MODE = "white_night_mode_sp"

    /**
     * Called in the onCreate() method of the Application
     */
    fun init(application: Application) {
        val nightMode = getNightModel(application)
        AppCompatDelegate.setDefaultNightMode(nightMode)
    }

    /**
     * Apply night mode
     */
    fun applyNightMode(context: Context) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        setNightModel(context, AppCompatDelegate.MODE_NIGHT_YES)
    }

    /**
     * Apply daytime mode
     */
    fun applyDayMode(context: Context) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
        setNightModel(context, AppCompatDelegate.MODE_NIGHT_NO)
    }

    /**
     * When following the system theme, you need to switch dynamically
     */
    fun applySystemMode(context: Context) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
        setNightModel(context, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }

    /**
     * Check whether the app is in dark mode
     */
    fun isDarkMode(context: Context): Boolean {
        val nightMode = getNightModel(context)
        return if (nightMode == AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM) {
            val applicationUiMode = context.resources.configuration.uiMode
            val systemMode = applicationUiMode and Configuration.UI_MODE_NIGHT_MASK
            systemMode == Configuration.UI_MODE_NIGHT_YES
        } else {
            nightMode == AppCompatDelegate.MODE_NIGHT_YES
        }
    }

    private fun getNightModel(context: Context): Int {
        val sp = context.getSharedPreferences(KEY_MODE, Context.MODE_PRIVATE)
        return sp.getInt(KEY_MODE, AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM)
    }

    fun setNightModel(context: Context, nightMode: Int) {
        val sp = context.getSharedPreferences(KEY_MODE, Context.MODE_PRIVATE)
        sp.edit().putInt(KEY_MODE, nightMode).apply()
    }
}