package com.example.myapplication.entity

import java.io.Serializable

/*Weather forecast for the next 7 days*/
class Weather7d : Serializable {
    var status = 0
    var result: ResultDTO? = null

    class ResultDTO : Serializable {
        var location: LocationDTO? = null
        var daily_fcsts: List<DailyFcstsDTO>? = null
        var last_update: String? = null

        class LocationDTO : Serializable {
            var areacode: String? = null
            var name: String? = null
            var country: String? = null
            var path: String? = null
        }

        class DailyFcstsDTO : Serializable {
            var text_day: String? = null
            var code_day: String? = null
            var text_night: String? = null
            var code_night: String? = null
            var high = 0
            var low = 0
            var wc_day: String? = null
            var wd_day: String? = null
            var wc_night: String? = null
            var wd_night: String? = null
            var wa_day = 0
            var wa_night = 0
            var ws_day = 0.0
            var ws_night = 0.0
            var pop = 0
            var pressure = 0
            var maxrh = 0
            var minrh = 0
            var vis = 0
            var clouds_day = 0
            var clouds_night = 0
            var uv = 0
            var date: String? = null
            var week: String? = null
        }
    }
}