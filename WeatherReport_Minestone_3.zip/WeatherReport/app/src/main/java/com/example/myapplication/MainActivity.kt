package com.example.myapplication

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.CityNaviAdapter
import com.example.myapplication.adapter.FutureTempAdapter
import com.example.myapplication.adapter.TodayTempAdapter
import com.example.myapplication.db.DbUtil
import com.example.myapplication.entity.Location
import com.example.myapplication.entity.ReverseGeocode
import com.example.myapplication.entity.Temp
import com.example.myapplication.entity.WeatherNowNew
import com.example.myapplication.util.DarkModeUtils.applyDayMode
import com.example.myapplication.util.DarkModeUtils.applyNightMode
import com.example.myapplication.util.DarkModeUtils.isDarkMode
import com.example.myapplication.util.MPermissionHelper
import com.example.myapplication.util.MPermissionHelper.PermissionCallBack
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.material.navigation.NavigationView
import com.google.gson.Gson
import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import kotlin.math.abs

class MainActivity : AppCompatActivity(), PermissionCallBack {
    //Control related
    private var drawerLayout: DrawerLayout? = null
    private var navView: NavigationView? = null
    private var iv_menu: ImageView? = null
    private var tv_temp_now: TextView? = null
    private var iv_icon: ImageView? = null
    private var tv_weather: TextView? = null
    private var tv_location: TextView? = null
    private var tv_temp_today: TextView? = null
    private var tv_temp_body: TextView? = null
    private var rv_today: RecyclerView? = null
    private var rv_temp_future: RecyclerView? = null
    private var tv_my_location: TextView? = null
    private var rv_locations: RecyclerView? = null
    private var tv_location_manage: TextView? = null
    private var tv_wind: TextView? = null
    private var tv_humidity: TextView? = null
    private var pb_loading: ProgressBar? = null
    private var tv_temp_navi: TextView? = null
    private var iv_icon_navi: ImageView? = null

    //permission class
    private var permissionHelper: MPermissionHelper? = null

    //Today's weather list adapter
    private var mTodayTempAdapter: TodayTempAdapter? = null

    //Weather list adapter for the next 7 days
    private var mFutureTempAdapter: FutureTempAdapter? = null

    //Sideslip menu position list adapter
    private var mCityNaviAdapter: CityNaviAdapter? = null

    //Database Management Class
    private var mDbUtil: DbUtil? = null

    //Positioning city information
    private var location: Location? = null
    private var temp //temperature
            : String? = null
    private var weatherNow //Positioning the City Today's Weather
            : WeatherNowNew.CurrentDTO? = null

    /**
     * sensor
     */
    private var sensorManager: SensorManager? = null
    private var shakeListener: ShakeSensorListener? =
        null

    /**
     * Judge the shake and shake action at a time
     */
    private var isShake = false

    private var isLoading = false

    private lateinit var fusedLocationClient: FusedLocationProviderClient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        iv_menu = findViewById(R.id.iv_menu)
        tv_temp_now = findViewById(R.id.tv_temp_now)
        iv_icon = findViewById(R.id.iv_icon)
        tv_location = findViewById(R.id.tv_location)
        tv_temp_today = findViewById(R.id.tv_temp_today)
        tv_temp_body = findViewById(R.id.tv_temp_body)
        rv_today = findViewById(R.id.rv_today)
        rv_temp_future = findViewById(R.id.rv_temp_days)
        tv_wind = findViewById(R.id.tv_wind)
        tv_humidity = findViewById(R.id.tv_humidity)
        pb_loading = findViewById(R.id.pb_loading)
        tv_weather = findViewById(R.id.tv_weather)
        val headerView = navView!!.getHeaderView(0)
        tv_my_location = headerView.findViewById(R.id.tv_my_location)
        rv_locations = headerView.findViewById(R.id.rv_locations)
        tv_location_manage = headerView.findViewById(R.id.tv_location_manage)
        tv_temp_navi = headerView.findViewById(R.id.tv_temp)
        iv_icon_navi = headerView.findViewById(R.id.iv_icon)
        val rl_location = headerView.findViewById<RelativeLayout>(R.id.rl_location)

        //Dynamically apply for GPS permission
        permissionHelper = MPermissionHelper(this@MainActivity)
        permissionHelper!!.requestPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
        )
        pb_loading?.visibility = View.VISIBLE

        //Pop up sideslip menu
        iv_menu?.setOnClickListener(View.OnClickListener {
            drawerLayout?.openDrawer(GravityCompat.START) //Click to open the side sliding drawer
            if (mCityNaviAdapter!!.itemCount == 0) { //Refresh Sideslip Menu Data
                refreshNaviData()
            }
        })
        rl_location.setOnClickListener {
            drawerLayout?.closeDrawers()
            pb_loading?.visibility = View.VISIBLE

            if (location != null) {
                tv_location?.text = location!!.name
                getWeatherData(location!!.name)
            }
        }
        //Manage Location List
        tv_location_manage?.setOnClickListener(View.OnClickListener {
            startActivityForResult(
                Intent(
                    this@MainActivity,
                    LocationManageActivity::class.java
                ), 886
            )
        })

        //Swipe the menu to switch between night and day modes
        navView!!.setNavigationItemSelectedListener { item ->
            drawerLayout?.closeDrawers()
            when (item.itemId) {
                R.id.nav_night_mode -> {
                    //If the current night mode is in night, the daytime mode will be restored
                    if (isDarkMode(this@MainActivity)) {
                        applyDayMode(this@MainActivity)
                    } else {//If the current mode is daytime, the nighttime mode will be restored
                        applyNightMode(this@MainActivity)
                    }
                    recreate() //The switch can be successfully completed after the reload
                    refreshNightModeTitle()
                }
            }
            true
        }

        //Restore based on the cached state of the last topic
        if (isDarkMode(this)) {
            applyNightMode(this)
        } else {
            applyDayMode(this)
        }
        refreshNightModeTitle();

        mDbUtil = DbUtil()
        refreshSaveData()
        initWeatherToday()
        initWeather7Day()
        initLocationNavi()

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        shakeListener = ShakeSensorListener()
    }

    //Initialize today's weather list
    private fun initWeatherToday() {
        rv_today!!.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        mTodayTempAdapter = TodayTempAdapter(this, ArrayList())
        rv_today!!.adapter = mTodayTempAdapter
    }

    //Initialize the weather list for the next 7 days
    private fun initWeather7Day() {
        rv_temp_future!!.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mFutureTempAdapter = FutureTempAdapter(this, ArrayList())
        rv_temp_future!!.adapter = mFutureTempAdapter
    }

    //Initialize the list of sliding menu positions
    private fun initLocationNavi() {
        rv_locations!!.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mCityNaviAdapter = CityNaviAdapter(this, ArrayList())
        rv_locations!!.adapter = mCityNaviAdapter
    }

    //Obtaining location information from database cache and weather display for a smoother experience
    private fun refreshSaveData() {
        val location = mDbUtil!!.getLocationBySelf(this@MainActivity)
        if (location != null) {
            tv_location!!.text = if (!TextUtils.isEmpty(location.name)) location.name else ""
            tv_temp_now!!.text = String.format("%s°", location.temp)
            tv_temp_body!!.text = String.format("Feel temperature %s°", location.feelsLike)
            //            Sharp.loadAsset(getAssets(), location.getIconDay()+".svg").into(iv_icon);
            tv_weather!!.text = location.text
            tv_wind!!.text = String.format("%s", location.windScale)
            tv_humidity!!.text = String.format("%s", location.humidity + "%")
        }
    }

    /**
     * Sliding window display
     */
    private fun refreshNightModeTitle() {
        if (isDarkMode(this@MainActivity)) {
            navView!!.menu.findItem(R.id.nav_night_mode).title = "Night mode"
        } else {
            navView!!.menu.findItem(R.id.nav_night_mode).title = "Daytime mode"
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permissionHelper!!.handleRequestPermissionsResult(requestCode, this, grantResults)
    }

    //Locating to obtain location information
    @SuppressLint("MissingPermission")
    private fun getLocationNew() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        fusedLocationClient.lastLocation.addOnSuccessListener {
            it ?: return@addOnSuccessListener
            handleLocation(it)
        }
    }

    /**
     * Reverse geocoding location
     */
    private fun handleLocation(location: android.location.Location) {
        Log.d("handleLocation", location.latitude.toString() + ";;" + location.longitude)
        Thread(Runnable {
            reverseGeocode(location)

        }).start()
    }

    /**
     * Reverse geocoding location location
     */
    private fun reverseGeocode(locationTemp: android.location.Location) {
        val client = OkHttpClient().newBuilder().build()
        val mediaType = MediaType.parse("application/x-www-form-urlencoded")
        val request = Request.Builder()
            .url(
                String.format(
                    "https://geocode.arcgis.com/arcgis/rest/services/World/GeocodeServer/reverseGeocode?location=113,23&langCode=fa&outSR=&forStorage=false&f=pjson",
                    locationTemp.longitude,
                    locationTemp.latitude
                )
            )
            .method("GET", null)
//                .addHeader("X-APISpace-Token", "7r1xcuaay34b9u34tgh9n219k23op6g2")
            .build()
        try {
            val response = client.newCall(request).execute()
            val result = response.body()!!.string()
            runOnUiThread {
                Log.d("handleLocation", result)
                val reverseGeocodeInfo = Gson().fromJson(
                    result,
                    ReverseGeocode::class.java
                )
                if (reverseGeocodeInfo?.address != null) {
                    reverseGeocodeInfo?.address?.city = "guangzhou"
                    location = Location(reverseGeocodeInfo.address?.city, locationTemp.latitude.toString(), locationTemp.longitude.toString())
                    tv_location!!.text = reverseGeocodeInfo.address?.city
                    tv_my_location!!.text = reverseGeocodeInfo.address?.city

                    Thread(Runnable {
                        reverseGeocodeInfo.address?.city?.let {
                            getWeatherNowNew(it)

                            getWeather24HourlyNew(it)

                        }
                    }).start()
                }
//                pb_loading!!.visibility = View.GONE
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //Obtaining Intelligent Weather Facts
    private fun getWeatherNowNew(city: String?) {
        val client = OkHttpClient().newBuilder().build()
        val request = Request.Builder()
            .url("https://weatherapi-com.p.rapidapi.com/current.json?q=$city")
            .get()
            .addHeader("X-RapidAPI-Key", "1ea43e3edbmshab31a44eb2756f2p12ef53jsnb8c60c62a960")
            .addHeader("X-RapidAPI-Host", "weatherapi-com.p.rapidapi.com")
            .build()
        try {
            val response = client.newCall(request).execute()
            val result = response.body()!!.string()
            runOnUiThread {
                val weatherNowBean = Gson().fromJson(
                    result,
                    WeatherNowNew::class.java
                )
                if (weatherNowBean?.current != null) {
                    val currentBean = weatherNowBean.current
                    tv_temp_now!!.text = String.format("%s°", currentBean!!.temp_c)
                    tv_temp_body!!.text = String.format("Feel temperature %s°", currentBean.feelslike_c)
                    tv_weather!!.text = currentBean.condition?.text
                    tv_wind!!.text = String.format("%s", currentBean.uv)
                    tv_humidity!!.text = String.format("%s%s", currentBean.humidity, "%")
                    val currentCity = tv_location!!.text.toString()
                    if (TextUtils.equals(location!!.name, currentCity)) { //My own position
                        weatherNow = currentBean
                        location!!.text = currentBean.condition?.text
                    } else {
                        weatherNow = null
                    }
                }
                pb_loading!!.visibility = View.GONE
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //Weather in the next 24 hours
    private fun getWeather24HourlyNew(city: String?) {
        val client = OkHttpClient().newBuilder().build()
        val request = Request.Builder()
            .url("https://weatherapi-com.p.rapidapi.com/forecast.json?q=$city&days=7")
            .get()
            .addHeader("X-RapidAPI-Key", "1ea43e3edbmshab31a44eb2756f2p12ef53jsnb8c60c62a960")
            .addHeader("X-RapidAPI-Host", "weatherapi-com.p.rapidapi.com")
            .build()

        try {
            val response = client.newCall(request).execute()
            val result = response.body()!!.string()
            runOnUiThread {
                val weather7d = Gson().fromJson(
                    result,
                    WeatherNowNew::class.java
                )
                val weather7dList = weather7d?.forecast?.forecastday
                if (weather7dList != null && weather7dList.isNotEmpty()) {
                    val weather24hList = weather7dList[0].hour
                    if (weather24hList != null && weather24hList.isNotEmpty()) {
                        val todayTemps: MutableList<Temp> =
                            ArrayList()
                        for (hourlyBean in weather24hList) {
                            val temp = Temp()
                            temp.time = hourlyBean.time?.trim()?.replace(weather7dList[0].date.toString(),"")
                            temp.prec = hourlyBean.uv.toString()
                            temp.temp = String.format("%s°", hourlyBean.temp_c)
                            temp.wind = String.format("%s%s", hourlyBean.chance_of_rain, "%")
                            temp.text = hourlyBean.condition?.text?.trim()
                            todayTemps.add(temp)
                        }
                        mTodayTempAdapter!!.update(todayTemps)
                        rv_today!!.visibility = View.VISIBLE
                    }

                    val futureTemps: MutableList<Temp> =
                        ArrayList()
                    for (dailyInfo in weather7dList) {
                        val dailyBean = dailyInfo.day
                        val temp = Temp()
                        temp.time = dailyInfo.date
                        temp.pop = String.format("%s%s", dailyBean!!.avghumidity, "%")
                        temp.tempRange =
                            String.format("%s°～%s°", dailyBean.mintemp_c, dailyBean.maxtemp_c)
                        temp.text = dailyBean.condition?.text?.trim()
                        futureTemps.add(temp)
                    }
                    mFutureTempAdapter!!.update(futureTemps)
                    rv_temp_future!!.visibility = View.VISIBLE

                    try {
                        val tempToday = futureTemps[0]
                        tv_temp_today!!.text = tempToday.tempRange
                        temp = tempToday.tempRange
                        val currentCity = tv_location!!.text.toString()
                        if (TextUtils.equals(location!!.name, currentCity)) { //My own position
                            var location = mDbUtil!!.getLocationBySelf(this@MainActivity)
                            val isUpdate = location != null
                            if (location == null) {
                                location = Location()
                            }
                            location.name = tv_location!!.text.toString()
                            location.self = 1
                            location.iconDay = tempToday.icon
                            location.temp = tempToday.temp
                            location.tempRange = tempToday.tempRange
                            location.humidity = tempToday.pop
                            location.text = tempToday.text
                            if (weatherNow != null) {
                                location.text = weatherNow?.condition?.text
                                location.feelsLike =
                                    java.lang.String.valueOf(weatherNow!!.feelslike_c)
                                location.windScale = weatherNow!!.uv.toString()
                                if (TextUtils.isEmpty(location.temp)) {
                                    location.temp = weatherNow!!.temp_c.toString()
                                }
                            }
                            if (isUpdate) {
                                mDbUtil!!.updateLocation(this@MainActivity, location)
                            } else {
                                mDbUtil!!.insertLocation(this@MainActivity, location)
                            }
                        } else {
                            var location =
                                mDbUtil!!.getLocationByName(this@MainActivity, currentCity)
                            val isUpdate = location != null
                            if (location == null) {
                                location = Location()
                            }
                            location.name = tv_location!!.text.toString()
                            location.self = 0
                            location.iconDay = tempToday.icon
                            location.temp = tempToday.temp
                            location.tempRange = tempToday.tempRange
                            location.text = tempToday.text
                            if (isUpdate) {
                                mDbUtil!!.updateLocation(this@MainActivity, location)
                            } else {
                                mDbUtil!!.insertLocation(this@MainActivity, location)
                            }
                        }
                        refreshNaviData()
                    } catch (e: Exception) {
                    }

                }
                pb_loading!!.visibility = View.GONE
            }
        } catch (e: IOException) {
            e.printStackTrace()
        } finally {
            isLoading = false
        }
    }

    private fun getWeatherData(city: String?) {
        isLoading = true
        Thread {
            getWeatherNowNew(city)

            getWeather24HourlyNew(city)
        }.start()
    }

    //Refresh the position data of the sliding menu
    private fun refreshNaviData() {
        if(location==null) return
        tv_my_location!!.text = location!!.name
        tv_temp_navi!!.text = temp

        tv_weather!!.text = location!!.text
        var locations = mDbUtil!!.getAllLocationExceptSelf(this@MainActivity)
        if (locations.size > 3) {
            locations = locations.subList(0, 3)
        }
        mCityNaviAdapter!!.update(locations)
        mCityNaviAdapter!!.setOnItemClickListener(object : CityNaviAdapter.OnItemClickListener {
            override fun onContentClick(location: Location?, position: Int) {
                drawerLayout!!.closeDrawers()
                pb_loading!!.visibility = View.VISIBLE

                tv_location!!.text = location!!.name
                getWeatherData(location.name)
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 886 && resultCode == RESULT_OK && data != null) { //Select location to return to refreshing weather data
            val location = data.getSerializableExtra("location") as Location?
            if (location != null) {
                drawerLayout!!.closeDrawers()
                pb_loading!!.visibility = View.VISIBLE

                tv_location!!.text = location.name
                getWeatherData(location.name)
            }
        }
    }

    override fun permissionRegisterSuccess(vararg permissions: String?) {
        //Obtain location information
//        getLocation()
//        getLocationNew()

        var location: android.location.Location? = null
        location = android.location.Location("")
        location?.latitude = 23.0
        location?.longitude = 113.0
        handleLocation(location!!)
    }

    override fun permissionRegisterError(vararg permissions: String?) {
    }

    override fun onResume() {
        //Register the monitor accelerometer
        sensorManager!!.registerListener(
            shakeListener, sensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
            SensorManager.SENSOR_DELAY_FASTEST
        )
        super.onResume()
    }

    override fun onPause() {
        /**
         * Resource release
         */
        sensorManager!!.unregisterListener(shakeListener)
        super.onPause()
    }

    private inner class ShakeSensorListener : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            //Avoid shaking all the time
            if (isShake || isLoading) {
                return
            }
            val values: FloatArray = event.values
            /*
             * x : Acceleration due to gravity in the direction of the x-axis, positive to the right
             * y : Acceleration due to gravity in the y-axis direction, which is positive forward
             * z : Acceleration due to gravity in the direction of the z-axis, which is positive upward
             */
            val x = abs(values[0])
            val y = abs(values[1])
            val z = abs(values[2])
            //The acceleration exceeds 39, and the shake is successful
            if (x > 39 || y > 39 || z > 39) {
                isShake = true
                //Play a sound
                playSound(this@MainActivity)
                //Shake, pay attention to permissions
                vibrate(500)
                //Imitation network delay operation, here you can go to the server weather data...
                Handler(Looper.getMainLooper()).postDelayed({
                    isShake = false
                    val locations = mDbUtil?.getCityData()
                    val city = locations?.get(java.util.Random().nextInt(locations.size))?.name

                    tv_location!!.text = city
                    pb_loading!!.visibility = View.VISIBLE

                    getWeatherData(city)
                }, 1000)
            }
        }

        override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
    }
    //Play a sound
    private fun playSound(context: Context) {
        val player: MediaPlayer = MediaPlayer.create(context, R.raw.shake_sound)
        player.start()
    }
    //Shake
    private fun vibrate(milliseconds: Long) {
        val vibrator = getSystemService(VIBRATOR_SERVICE) as Vibrator
        vibrator.vibrate(milliseconds)
    }
}