package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.LocationAdapter
import com.example.myapplication.db.DbUtil
import com.example.myapplication.entity.Location

/*location management*/
class LocationManageActivity : AppCompatActivity() {
    private var rv_positions: RecyclerView? = null
    private var mDbUtil: DbUtil? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_manage)
        rv_positions = findViewById(R.id.rv_positions)
        mDbUtil = DbUtil()
        rv_positions?.layoutManager = LinearLayoutManager(this)
        val adapter = LocationAdapter(this, mDbUtil!!.getAllLocationExceptSelf(this))
        rv_positions?.adapter = adapter
        adapter.setOnItemClickListener(object : LocationAdapter.OnItemClickListener {
            override fun onContentClick(location: Location?, position: Int) {
                setResult(RESULT_OK, Intent().putExtra("location", location))
                finish()
            }
        })
    }

    fun clickBack(view: View?) {
        finish()
    }

    /*Add location information*/
    fun clickAddPosition(view: View?) {
        startActivityForResult(
            Intent(
                this@LocationManageActivity,
                LocationInsertActivity::class.java
            ), 996
        )
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 996 && resultCode == RESULT_OK && data != null) { //Add Location Return
            setResult(RESULT_OK, Intent().putExtra("location", data.getSerializableExtra("area")))
            finish()
        }
    }
}