package com.example.myapplication.entity

import com.google.gson.annotations.SerializedName
import java.io.Serializable

class ReverseGeocode : Serializable {
    var address: AddressDTO? = null
    var location: LocationDTO? = null

    class AddressDTO : Serializable {
        @SerializedName("Match_addr")
        var match_addr: String? = null

        @SerializedName("LongLabel")
        var longLabel: String? = null

        @SerializedName("ShortLabel")
        var shortLabel: String? = null

        @SerializedName("Addr_type")
        var addr_type: String? = null

        @SerializedName("Type")
        var type: String? = null

        @SerializedName("PlaceName")
        var placeName: String? = null

        @SerializedName("AddNum")
        var addNum: String? = null

        @SerializedName("Address")
        var address: String? = null

        @SerializedName("Block")
        var block: String? = null

        @SerializedName("Sector")
        var sector: String? = null

        @SerializedName("Neighborhood")
        var neighborhood: String? = null

        @SerializedName("District")
        var district: String? = null

        @SerializedName("City")
        var city: String? = null

        @SerializedName("MetroArea")
        var metroArea: String? = null

        @SerializedName("Subregion")
        var subregion: String? = null

        @SerializedName("Region")
        var region: String? = null

        @SerializedName("RegionAbbr")
        var regionAbbr: String? = null

        @SerializedName("Territory")
        var territory: String? = null

        @SerializedName("Postal")
        var postal: String? = null

        @SerializedName("PostalExt")
        var postalExt: String? = null

        @SerializedName("CntryName")
        var cntryName: String? = null

        @SerializedName("CountryCode")
        var countryCode: String? = null

    }

    class LocationDTO : Serializable {
        var x = 0.0
        var y = 0.0
        var spatialReference: SpatialReferenceDTO? = null

        class SpatialReferenceDTO : Serializable {
            var wkid = 0.0
            var latestWkid = 0.0
        }
    }
}