package com.example.myapplication.util

import android.annotation.SuppressLint
import android.content.Context
import android.content.SharedPreferences
import android.text.TextUtils
import com.example.myapplication.MyApplication
import java.text.SimpleDateFormat
import java.util.*

/**
 * Commonly used tools
 */
object SpUtil {
    /**
     * Storage int type
     */
    fun setIntSharedPreference(key: String?, value: Int) {
        val pref: SharedPreferences =
            MyApplication.Companion.sInstance!!.getSharedPreferences("info", Context.MODE_PRIVATE)
        val editor = pref.edit()
        editor.putInt(key, value)
        editor.commit()
    }

    /**
     * String storage type
     */
    fun setStringSharedPreference(key: String?, value: String?) {
        val pref: SharedPreferences =
            MyApplication.Companion.sInstance!!.getSharedPreferences("info", Context.MODE_PRIVATE)
        val editor = pref.edit()
        editor.putString(key, value)
        editor.commit()
    }

    /**
     * Obtain the int sharedPreference
     */
    fun getIntSharedPreference(key: String?): Int {
        val pref: SharedPreferences =
            MyApplication.Companion.sInstance!!.getSharedPreferences("info", Context.MODE_PRIVATE)
        return pref.getInt(key, 0)
    }

    /**
     * Obtain the String sharedPreference
     */
    fun getStringSharedPreference(key: String?): String? {
        val pref: SharedPreferences =
            MyApplication.Companion.sInstance!!.getSharedPreferences("info", Context.MODE_PRIVATE)
        return pref.getString(key, null)
    }

    /**
     * The timestamp obtains the year, month, day, and minute
     */
    fun getyMdHm(time: Long?): String {
        if (time == null || time == 0L) {
            return ""
        }
        @SuppressLint("SimpleDateFormat") val sdf =
            SimpleDateFormat("yyyy-MM-dd HH:mm")
        return sdf.format(time)
    }

    /**
     * Time stamp acquisition time
     */
    fun getyH(time: Long?): String? {
        if (time == null || time == 0L) {
            return ""
        }
        @SuppressLint("SimpleDateFormat") val sdf =
            SimpleDateFormat("HH:mm")
        return sdf.format(time)
    }

    /**
     * Obtain timestamp from year, month, day, hour, minute, and second
     */
    fun getTimeMillis(time: String?): Long {
        if (TextUtils.isEmpty(time)) {
            return 0
        }
        val formatter = SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
        val date: Date
        try {
            date = formatter.parse(time)
            return date.time
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return 0
    }

    /**
     * Obtaining time from year, month, day, hour, minute, second
     */
    fun getyH(time: String?): String? {
        return getyH(getTimeMillis(time))
    }

}