package com.example.myapplication.adapter

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import android.widget.TextView
import com.example.myapplication.R
import android.view.ViewGroup
import android.view.LayoutInflater
import android.view.View
import com.example.myapplication.entity.Area
import com.example.myapplication.entity.Location

/*City list adapter*/
class CityAdapter(private val context: Context, private val mCityEntity: MutableList<Location?>) :
    RecyclerView.Adapter<CityAdapter.ViewHolder>() {
    private var onItemClickListener: OnItemClickListener? = null

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvCityName: TextView

        init {
            tvCityName = itemView.findViewById(R.id.tvCityName)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view =
            LayoutInflater.from(context).inflate(R.layout.rv_item_city, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.tvCityName.text = mCityEntity[position]?.name
        holder.itemView.setOnClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onContentClick(mCityEntity[position], holder.adapterPosition)
            }
        }
    }

    override fun getItemCount(): Int {
        return mCityEntity.size
    }

    fun update(cityEntityList: List<Location?>?) {
        mCityEntity.clear()
        mCityEntity.addAll(cityEntityList!!)
        notifyDataSetChanged()
    }

    interface OnItemClickListener {
        fun onContentClick(city: Location?, position: Int)
    }

    fun setOnItemClickListener(onItemClickListener: OnItemClickListener?) {
        this.onItemClickListener = onItemClickListener
    }
}