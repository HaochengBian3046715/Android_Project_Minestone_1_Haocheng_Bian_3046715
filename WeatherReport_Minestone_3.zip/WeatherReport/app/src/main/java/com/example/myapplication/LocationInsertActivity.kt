package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.CityAdapter
import com.example.myapplication.db.DbUtil
import com.example.myapplication.entity.Location
import java.util.*

/*Add location information*/
class LocationInsertActivity : AppCompatActivity() {
    private var rvCity: RecyclerView? = null
    private var btnSearch: Button? = null
    private var etCity: AppCompatEditText? = null
    private var cityAdapter: CityAdapter? = null
    private val locations: MutableList<Location?> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_insert)
        rvCity = findViewById(R.id.rvCity)
        btnSearch = findViewById(R.id.btnSearch)
        etCity = findViewById(R.id.etCity)

        //Obtain your current positioning information
        val util = DbUtil()
        locations.clear()
        locations.addAll(util.getCityData())

        //Set up city list adapter
        rvCity?.layoutManager = LinearLayoutManager(this@LocationInsertActivity)
        cityAdapter = CityAdapter(this@LocationInsertActivity, locations)
        rvCity?.adapter = cityAdapter
        //Click on the city to return to the main interface and refresh the weather
        cityAdapter!!.setOnItemClickListener(object : CityAdapter.OnItemClickListener {
            override fun onContentClick(area: Location?, position: Int) {
                setResult(
                    RESULT_OK, Intent().putExtra(
                        "area", Location(
                            area!!.name,
                            java.lang.String.valueOf(area.lat),
                            java.lang.String.valueOf(area.lon)
                        )
                    )
                )
                finish()
            }
        })
        btnSearch?.setOnClickListener(View.OnClickListener {
            val input = etCity?.text.toString()
            if (TextUtils.isEmpty(input)) {
                cityAdapter!!.update(util.getCityData())
            } else {
                val locationsTemp: MutableList<Location?> = java.util.ArrayList()
                for (area in util.getCityData()) {
                    if (input.lowercase(Locale.getDefault()).contains(area?.name?.lowercase(Locale.getDefault()).toString())
                        || area?.name?.lowercase(Locale.getDefault())!!.lowercase(Locale.getDefault()).contains(input)
                    ) {
                        locationsTemp.add(area)
                    }
                }
                cityAdapter!!.update(locationsTemp)
            }
        })
    }

    fun clickBack(view: View?) {
        finish()
    }
}