package com.example.myapplication.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.entity.Location

/*Swipe menu city list adapter*/
class CityNaviAdapter(
    private val context: Context,
    private val mCityEntity: MutableList<Location?>
) : RecyclerView.Adapter<CityNaviAdapter.ViewHolder>() {
    private var onItemClickListener: OnItemClickListener? = null

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tvCityName: TextView
        var tv_temp: TextView
        var iv_icon: ImageView
        var tv_weather: TextView

        init {
            tvCityName = itemView.findViewById(R.id.tvCityName)
            tv_temp = itemView.findViewById(R.id.tv_temp)
            iv_icon = itemView.findViewById(R.id.iv_icon)
            tv_weather = itemView.findViewById(R.id.tv_weather)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view =
            LayoutInflater.from(context).inflate(R.layout.rv_item_city_navi, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val location = mCityEntity[position]
        holder.tvCityName.text = mCityEntity[position]?.name
        holder.tv_temp.text = mCityEntity[position]?.tempRange
//        holder.tv_weather.text = location!!.text

        holder.itemView.setOnClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onContentClick(location, holder.adapterPosition)
            }
        }
    }

    override fun getItemCount(): Int {
        return mCityEntity.size
    }

    fun update(cityEntityList: List<Location?>?) {
        mCityEntity.clear()
        mCityEntity.addAll(cityEntityList!!)
        notifyDataSetChanged()
    }

    interface OnItemClickListener {
        fun onContentClick(location: Location?, position: Int)
    }

    fun setOnItemClickListener(onItemClickListener: OnItemClickListener?) {
        this.onItemClickListener = onItemClickListener
    }
}