package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatEditText
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.CityAdapter
import com.example.myapplication.db.DbUtil
import com.example.myapplication.entity.Area
import com.example.myapplication.entity.Area.AreaListDTO
import com.example.myapplication.entity.Location
import com.google.gson.Gson
import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

/*Add location information*/
class LocationInsertActivity : AppCompatActivity() {
    private var rvCity: RecyclerView? = null
    private var btnSearch: Button? = null
    private var etCity: AppCompatEditText? = null
    private var cityAdapter: CityAdapter? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_location_insert)
        rvCity = findViewById(R.id.rvCity)
        btnSearch = findViewById(R.id.btnSearch)
        etCity = findViewById(R.id.etCity)

        //Obtain your current positioning information
        val util = DbUtil()
        val location = util.getLocationBySelf(this)

        //Set up city list adapter
        rvCity?.layoutManager = LinearLayoutManager(this@LocationInsertActivity)
        cityAdapter = CityAdapter(this@LocationInsertActivity, ArrayList())
        rvCity?.adapter = cityAdapter
        //Click on the city to return to the main interface and refresh the weather
        cityAdapter!!.setOnItemClickListener(object : CityAdapter.OnItemClickListener {
            override fun onContentClick(area: AreaListDTO?, position: Int) {
                setResult(
                    RESULT_OK, Intent().putExtra(
                        "area", Location(
                            area!!.name,
                            java.lang.String.valueOf(area.lat),
                            java.lang.String.valueOf(area.lon)
                        )
                    )
                )
                finish()
            }
        })
        getAreaData(location!!.name)
        btnSearch?.setOnClickListener(View.OnClickListener {
            val input = etCity?.text.toString()
            if (TextUtils.isEmpty(input)) {
                getAreaData(location.name)
            } else {
                getAreaData(input)
            }
        })
    }

    private fun getAreaData(city: String?) {
        //Start the thread to search for the location near the city
        Thread { getAreaList(city) }.start()
    }

    //Get City List
    private fun getAreaList(city: String?) {
        val client = OkHttpClient().newBuilder().build()
        val mediaType = MediaType.parse("application/x-www-form-urlencoded")
        val request = Request.Builder()
            .url(
                String.format(
                    "https://eolink.o.apispace.com/456456/function/v001/city?location=%s&items=20&area=global&language=ENG&withTz=&withPoi=true",
                    city
                )
            )
            .method("GET", null)
            .addHeader("X-APISpace-Token", "7r1xcuaay34b9u34tgh9n219k23op6g2")
            .build()
        try {
            val response = client.newCall(request).execute()
            val result = response.body()!!.string()
            Log.e("getAreaList:", result)
            runOnUiThread {
                val area = Gson().fromJson(
                    result,
                    Area::class.java
                )
                if (area != null) {
                    val areaList: List<AreaListDTO?>? = area.areaList
                    if (areaList != null && !areaList.isEmpty()) {
                        cityAdapter!!.update(areaList)
                    }
                }
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    fun clickBack(view: View?) {
        finish()
    }
}