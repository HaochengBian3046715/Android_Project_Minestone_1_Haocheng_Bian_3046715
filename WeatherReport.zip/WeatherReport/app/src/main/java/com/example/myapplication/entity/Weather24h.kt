package com.example.myapplication.entity

import java.io.Serializable

/*Future 24-hour weather forecast*/
class Weather24h : Serializable {
    var status = 0
    var result: ResultDTO? = null

    class ResultDTO : Serializable {
        var location: LocationDTO? = null
        var hourly_fcsts: List<HourlyFcstsDTO>? = null
        var last_update: String? = null

        class LocationDTO : Serializable {
            var areacode: String? = null
            var name: String? = null
            var country: String? = null
            var path: String? = null
        }

        class HourlyFcstsDTO : Serializable {
            var text: String? = null
            var code: String? = null
            var temp_fc = 0
            var wind_class: String? = null
            var wind_speed = 0.0
            var wind_dir: String? = null
            var wind_angle = 0
            var rh = 0
            var prec = 0.0
            var pressure = 0
            var clouds = 0
            var feels_like = 0
            var data_time: String? = null
        }
    }
}