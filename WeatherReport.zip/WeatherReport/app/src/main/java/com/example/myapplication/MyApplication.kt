package com.example.myapplication

import android.app.Application
import com.amap.api.location.AMapLocationClient

class MyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        sInstance = this
        //AutoNavi initialization
        AMapLocationClient.updatePrivacyShow(this, true, true)
        AMapLocationClient.updatePrivacyAgree(this, true)
    }

    companion object {
        var sInstance: MyApplication? = null
    }
}