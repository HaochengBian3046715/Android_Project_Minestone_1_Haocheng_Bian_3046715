package com.example.myapplication.entity

import java.io.Serializable

/*Regional entity*/
class Area : Serializable {
    var status = 0
    var areaList: List<AreaListDTO>? = null

    class AreaListDTO : Serializable {
        var areacode: String? = null
        var lon = 0.0
        var lat = 0.0
        var name: String? = null
        var country: String? = null
        var path: String? = null
        var timezone: String? = null
        var time_converter: String? = null
    }
}