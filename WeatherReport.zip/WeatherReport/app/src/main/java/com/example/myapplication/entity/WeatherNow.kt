package com.example.myapplication.entity

import java.io.Serializable

/*Today's weather forecast*/
class WeatherNow : Serializable {
    var status = 0
    var result: ResultDTO? = null

    class ResultDTO : Serializable {
        var realtime: RealtimeDTO? = null
        var last_update: String? = null

        class RealtimeDTO : Serializable {
            var text: String? = null
            var code: String? = null
            var temp = 0.0
            var feels_like = 0
            var rh = 0
            var wind_class: String? = null
            var wind_speed = 0.0
            var wind_dir: String? = null
            var wind_angle = 0
            var prec = 0
            var prec_time: String? = null
            var clouds = 0
            var vis = 0
            var pressure = 0
            var dew = 0
            var uv = 0
            var weight = 0
            var brief: String? = null
            var detail: String? = null
        }
    }
}