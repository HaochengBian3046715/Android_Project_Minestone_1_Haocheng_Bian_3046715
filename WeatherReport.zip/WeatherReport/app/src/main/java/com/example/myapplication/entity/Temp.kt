package com.example.myapplication.entity

import java.io.Serializable

/*Weather Entity Object*/
class Temp : Serializable {
    var time //time
            : String? = null
    var icon //icon
            : String? = null
    var temp //temperature
            : String? = null
    var prec //Precipitation in millimeters (mm)
            : String? = null
    var pop //Probability of precipitation, in%
            : String? = null
    var wind //Wind level
            : String? = null
    var tempRange //temperature range
            : String? = null
    var text //Weather text description
            : String? = null
}