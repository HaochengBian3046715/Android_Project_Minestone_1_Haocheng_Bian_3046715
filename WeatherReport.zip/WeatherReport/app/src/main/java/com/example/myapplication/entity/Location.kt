package com.example.myapplication.entity

import java.io.Serializable

/*Positional entity*/
class Location : Serializable {
    var id = 0
    var name //location name
            : String? = null
    var temp //temperature
            : String? = null
    var iconDay //weather icon
            : String? = null
    var tempRange //temperature range
            : String? = null
    var datetime //time
            : String? = null
    var self //Own positioning city
            = 0

    //Fields that may be empty, only the currently located weather will have
    var feelsLike //Apparent temperature
            : String? = null
    var windScale //Wind level
            : String? = null
    var humidity //precipitation probability
            : String? = null
    var text //Weather text description
            : String? = null
    var lat //latitude
            : String? = null
    var lon //longitude
            : String? = null

    constructor() {}
    constructor(name: String?, lat: String?, lon: String?) {
        this.name = name
        this.lat = lat
        this.lon = lon
    }
}