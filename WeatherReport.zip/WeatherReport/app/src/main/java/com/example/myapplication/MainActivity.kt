package com.example.myapplication

import android.Manifest
import android.content.Intent
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.adapter.CityNaviAdapter
import com.example.myapplication.adapter.FutureTempAdapter
import com.example.myapplication.adapter.TodayTempAdapter
import com.example.myapplication.db.DbUtil
import com.example.myapplication.entity.*
import com.example.myapplication.entity.WeatherNow.ResultDTO.RealtimeDTO
import com.example.myapplication.util.AMapLocationUtil
import com.example.myapplication.util.AMapLocationUtil.OnLocationListenerCallback
import com.example.myapplication.util.MPermissionHelper
import com.example.myapplication.util.MPermissionHelper.PermissionCallBack
import com.example.myapplication.util.SpUtil.getyH
import com.google.android.material.navigation.NavigationView
import com.google.gson.Gson
import okhttp3.MediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

class MainActivity : AppCompatActivity(), PermissionCallBack {
    //Control related
    private var drawerLayout: DrawerLayout? = null
    private var navView: NavigationView? = null
    private var iv_menu: ImageView? = null
    private var tv_temp_now: TextView? = null
    private var iv_icon: ImageView? = null
    private var tv_weather: TextView? = null
    private var tv_location: TextView? = null
    private var tv_temp_today: TextView? = null
    private var tv_temp_body: TextView? = null
    private var rv_today: RecyclerView? = null
    private var rv_temp_future: RecyclerView? = null
    private var tv_my_location: TextView? = null
    private var rv_locations: RecyclerView? = null
    private var tv_location_manage: TextView? = null
    private var tv_wind: TextView? = null
    private var tv_humidity: TextView? = null
    private var pb_loading: ProgressBar? = null
    private var tv_temp_navi: TextView? = null
    private var iv_icon_navi: ImageView? = null

    //permission class
    private var permissionHelper: MPermissionHelper? = null

    //Today's weather list adapter
    private var mTodayTempAdapter: TodayTempAdapter? = null

    //Weather list adapter for the next 7 days
    private var mFutureTempAdapter: FutureTempAdapter? = null

    //Sideslip menu position list adapter
    private var mCityNaviAdapter: CityNaviAdapter? = null

    //Database Management Class
    private var mDbUtil: DbUtil? = null

    //Positioning city information
    private var location: Location? = null
    private var temp //temperature
            : String? = null
    private var weatherNow //Positioning the City Today's Weather
            : RealtimeDTO? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        drawerLayout = findViewById(R.id.drawer_layout)
        navView = findViewById(R.id.nav_view)
        iv_menu = findViewById(R.id.iv_menu)
        tv_temp_now = findViewById(R.id.tv_temp_now)
        iv_icon = findViewById(R.id.iv_icon)
        tv_location = findViewById(R.id.tv_location)
        tv_temp_today = findViewById(R.id.tv_temp_today)
        tv_temp_body = findViewById(R.id.tv_temp_body)
        rv_today = findViewById(R.id.rv_today)
        rv_temp_future = findViewById(R.id.rv_temp_days)
        tv_wind = findViewById(R.id.tv_wind)
        tv_humidity = findViewById(R.id.tv_humidity)
        pb_loading = findViewById(R.id.pb_loading)
        tv_weather = findViewById(R.id.tv_weather)
        val headerView = navView!!.getHeaderView(0)
        tv_my_location = headerView.findViewById(R.id.tv_my_location)
        rv_locations = headerView.findViewById(R.id.rv_locations)
        tv_location_manage = headerView.findViewById(R.id.tv_location_manage)
        tv_temp_navi = headerView.findViewById(R.id.tv_temp)
        iv_icon_navi = headerView.findViewById(R.id.iv_icon)
        val rl_location = headerView.findViewById<RelativeLayout>(R.id.rl_location)

        //Dynamically apply for GPS permission
        permissionHelper = MPermissionHelper(this@MainActivity)
        permissionHelper!!.requestPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
        pb_loading?.visibility = View.VISIBLE

        //Pop up sideslip menu
        iv_menu?.setOnClickListener(View.OnClickListener {
            drawerLayout?.openDrawer(GravityCompat.START) //Click to open the side sliding drawer
            if (mCityNaviAdapter!!.itemCount == 0) { //Refresh Sideslip Menu Data
                refreshNaviData()
            }
        })
        rl_location.setOnClickListener {
            drawerLayout?.closeDrawers()
            pb_loading?.setVisibility(View.VISIBLE)

            if (location != null) {
                tv_location?.setText(location!!.name)
                getWeatherData(location!!.lat, location!!.lon)
            }
        }
        //Manage Location List
        tv_location_manage?.setOnClickListener(View.OnClickListener {
            startActivityForResult(
                Intent(
                    this@MainActivity,
                    LocationManageActivity::class.java
                ), 886
            )
        })

        mDbUtil = DbUtil()
        refreshSaveData()
        initWeatherToday()
        initWeather7Day()
        initLocationNavi()
    }

    //Initialize today's weather list
    private fun initWeatherToday() {
        rv_today!!.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        mTodayTempAdapter = TodayTempAdapter(this, ArrayList())
        rv_today!!.adapter = mTodayTempAdapter
    }

    //Initialize the weather list for the next 7 days
    private fun initWeather7Day() {
        rv_temp_future!!.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mFutureTempAdapter = FutureTempAdapter(this, ArrayList())
        rv_temp_future!!.adapter = mFutureTempAdapter
    }

    //Initialize the list of sliding menu positions
    private fun initLocationNavi() {
        rv_locations!!.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        mCityNaviAdapter = CityNaviAdapter(this, ArrayList())
        rv_locations!!.adapter = mCityNaviAdapter
    }

    //Obtaining location information from database cache and weather display for a smoother experience
    private fun refreshSaveData() {
        val location = mDbUtil!!.getLocationBySelf(this@MainActivity)
        if (location != null) {
            tv_location!!.text = if (!TextUtils.isEmpty(location.name)) location.name else ""
            tv_temp_now!!.text = String.format("%s°", location.temp)
            tv_temp_body!!.text = String.format("体感温度 %s°", location.feelsLike)
            //            Sharp.loadAsset(getAssets(), location.getIconDay()+".svg").into(iv_icon);
            tv_weather!!.text = location.text
            tv_wind!!.text = String.format("%s", location.windScale)
            tv_humidity!!.text = String.format("%s", location.humidity + "%")
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        permissionHelper!!.handleRequestPermissionsResult(requestCode, this, grantResults)
    }

    //Locating to obtain location information
    private fun getLocation() {
        AMapLocationUtil.get().init(this@MainActivity, object : OnLocationListenerCallback {
            override fun getLocation(lat: Double, lon: Double, city: String, address: String?) {
                location = Location(city.replace("市", ""), lat.toString(), lon.toString())
                tv_location!!.text = location!!.name
                tv_my_location!!.text = location!!.name

                getWeatherData(lat.toString(), lon.toString())
            }

            override val locationError: Unit
                get() {}
        })
    }

    //Obtaining Intelligent Weather Facts
    private fun getWeatherNow(lonlat: String) {
        val client = OkHttpClient().newBuilder().build()
        val mediaType = MediaType.parse("application/x-www-form-urlencoded")
        val request = Request.Builder()
            .url(
                String.format(
                    "https://eolink.o.apispace.com/456456/weather/v001/now?lonlat=%s",
                    lonlat
                )
            )
            .method("GET", null)
            .addHeader("X-APISpace-Token", "7r1xcuaay34b9u34tgh9n219k23op6g2")
            .build()
        try {
            val response = client.newCall(request).execute()
            val result = response.body()!!.string()
            runOnUiThread {
                val weatherNowBean = Gson().fromJson(
                    result,
                    WeatherNow::class.java
                )
                if (weatherNowBean?.result != null && weatherNowBean.result!!.realtime != null) {
                    val nowBaseBean = weatherNowBean.result!!.realtime
                    tv_temp_now!!.text = String.format("%s°", nowBaseBean!!.temp)
                    tv_temp_body!!.text = String.format("体感温度 %s°", nowBaseBean.feels_like)
                    //                Sharp.loadAsset(getAssets(), nowBaseBean.getIcon() + ".svg").into(iv_icon);
                    tv_weather!!.text = nowBaseBean.text
                    tv_wind!!.text = String.format("%s", nowBaseBean.wind_class)
                    tv_humidity!!.text = String.format("%s%s", nowBaseBean.rh, "%")
                    //                image = nowBaseBean.getIcon();
                    val currentCity = tv_location!!.text.toString()
                    if (TextUtils.equals(location!!.name, currentCity)) { //My own position
                        weatherNow = nowBaseBean
                        location!!.text = nowBaseBean.text
                    } else {
                        weatherNow = null
                    }
                }
                pb_loading!!.visibility = View.GONE
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //Weather in the next 24 hours
    private fun getWeather24Hourly(lonlat: String) {
        val client = OkHttpClient().newBuilder().build()
        val mediaType = MediaType.parse("application/x-www-form-urlencoded")
        val request = Request.Builder()
            .url(
                String.format(
                    "https://eolink.o.apispace.com/456456/weather/v001/hour?hours=24&lonlat=%s",
                    lonlat
                )
            )
            .method("GET", null)
            .addHeader("X-APISpace-Token", "7r1xcuaay34b9u34tgh9n219k23op6g2")
            .build()
        try {
            val response = client.newCall(request).execute()
            val result = response.body()!!.string()
            runOnUiThread {
                val weather24h = Gson().fromJson(result, Weather24h::class.java)
                if (weather24h != null && weather24h.result != null) {
                    val weather24hList = weather24h.result!!.hourly_fcsts
                    if (weather24hList != null && !weather24hList.isEmpty()) {
                        val todayTemps: MutableList<Temp> =
                            ArrayList()
                        for (hourlyBean in weather24hList) {
                            val temp = Temp()
                            if (!TextUtils.isEmpty(hourlyBean.data_time)) {
                                temp.time = getyH(hourlyBean.data_time)
                            }
                            temp.prec = java.lang.String.valueOf(hourlyBean.prec)
                            //                        temp.setIcon(hourlyBean.getIcon());
                            temp.temp = String.format("%s°", hourlyBean.temp_fc)
                            temp.wind = hourlyBean.wind_class
                            temp.text = hourlyBean.text
                            todayTemps.add(temp)
                        }
                        mTodayTempAdapter!!.update(todayTemps)
                        rv_today!!.visibility = View.VISIBLE
                    }
                }
                pb_loading!!.visibility = View.GONE
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    //Weather in the next 7 days
    private fun getWeather7D(lonlat: String) {
        val client = OkHttpClient().newBuilder().build()
        val mediaType = MediaType.parse("application/x-www-form-urlencoded")
        val request = Request.Builder()
            .url(
                String.format(
                    "https://eolink.o.apispace.com/456456/weather/v001/day?days=7&lonlat=%s",
                    lonlat
                )
            )
            .method("GET", null)
            .addHeader("X-APISpace-Token", "7r1xcuaay34b9u34tgh9n219k23op6g2")
            .build()
        try {
            val response = client.newCall(request).execute()
            val result = response.body()!!.string()
            runOnUiThread {
                val weather7d = Gson().fromJson(result, Weather7d::class.java)
                if (weather7d?.result != null) {
                    val weather7dList = weather7d.result!!.daily_fcsts
                    if (weather7dList != null && !weather7dList.isEmpty()) {
                        val futureTemps: MutableList<Temp> =
                            ArrayList()
                        for (dailyBean in weather7dList) {
                            val temp = Temp()
                            temp.time = dailyBean.date
                            temp.pop = java.lang.String.valueOf(dailyBean.pop)
                            //                        temp.setIcon(dailyBean.getIconDay());
                            temp.tempRange =
                                String.format("%s°～%s°", dailyBean.high, dailyBean.low)
                            temp.text = dailyBean.text_day
                            futureTemps.add(temp)
                        }
                        mFutureTempAdapter!!.update(futureTemps)
                        rv_temp_future!!.visibility = View.VISIBLE
                        try {
                            val tempToday = futureTemps[0]
                            tv_temp_today!!.text = tempToday.tempRange
                            temp = tempToday.tempRange
                            val currentCity = tv_location!!.text.toString()
                            if (TextUtils.equals(location!!.name, currentCity)) { //My own position
                                var location = mDbUtil!!.getLocationBySelf(this@MainActivity)
                                val isUpdate = location != null
                                if (location == null) {
                                    location = Location()
                                }
                                location.name = tv_location!!.text.toString()
                                location.self = 1
                                location.iconDay = tempToday.icon
                                location.temp = tempToday.temp
                                location.tempRange = tempToday.tempRange
                                location.humidity = tempToday.pop
                                location.text = tempToday.text
                                if (weatherNow != null) {
                                    location.feelsLike =
                                        java.lang.String.valueOf(weatherNow!!.feels_like)
                                    location.windScale = weatherNow!!.wind_class
                                    if (TextUtils.isEmpty(location.temp)) {
                                        location.temp = java.lang.String.valueOf(weatherNow!!.temp)
                                    }
                                }
                                if (isUpdate) {
                                    mDbUtil!!.updateLocation(this@MainActivity, location)
                                } else {
                                    mDbUtil!!.insertLocation(this@MainActivity, location)
                                }
                            } else {
                                var location =
                                    mDbUtil!!.getLocationByName(this@MainActivity, currentCity)
                                val isUpdate = location != null
                                if (location == null) {
                                    location = Location()
                                }
                                location.name = tv_location!!.text.toString()
                                location.self = 0
                                location.iconDay = tempToday.icon
                                location.temp = tempToday.temp
                                location.tempRange = tempToday.tempRange
                                location.text = tempToday.text
                                if (isUpdate) {
                                    mDbUtil!!.updateLocation(this@MainActivity, location)
                                } else {
                                    mDbUtil!!.insertLocation(this@MainActivity, location)
                                }
                            }
                            refreshNaviData()
                        } catch (e: Exception) {
                        }
                    }
                }
                pb_loading!!.visibility = View.GONE
            }
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }

    private fun getWeatherData(lat: String?, lon: String?) {
        Thread {
            getWeatherNow(String.format("%s,%s", lon, lat))
            getWeather24Hourly(String.format("%s,%s", lon, lat))
            getWeather7D(String.format("%s,%s", lon, lat))
        }.start()
    }

    //Refresh the position data of the sliding menu
    private fun refreshNaviData() {
        tv_my_location!!.text = location!!.name
        tv_temp_navi!!.text = temp

        tv_weather!!.text = location!!.text
        var locations = mDbUtil!!.getAllLocationExceptSelf(this@MainActivity)
        if (locations.size > 3) {
            locations = locations.subList(0, 3)
        }
        mCityNaviAdapter!!.update(locations)
        mCityNaviAdapter!!.setOnItemClickListener(object : CityNaviAdapter.OnItemClickListener {
            override fun onContentClick(location: Location?, position: Int) {
                drawerLayout!!.closeDrawers()
                pb_loading!!.visibility = View.VISIBLE

                tv_location!!.text = location!!.name
                getWeatherData(location.lat, location.lon)
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 886 && resultCode == RESULT_OK && data != null) { //Select location to return to refreshing weather data
            val location = data.getSerializableExtra("location") as Location?
            if (location != null) {
                drawerLayout!!.closeDrawers()
                pb_loading!!.visibility = View.VISIBLE

                tv_location!!.text = location.name
                getWeatherData(location.lat, location.lon)
            }
        }
    }

    override fun permissionRegisterSuccess(vararg permissions: String?) {
        //Obtain location information
        getLocation()
    }

    override fun permissionRegisterError(vararg permissions: String?) {
    }
}