package com.example.myapplication.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

/**
 * Database utility class
 */
class DbOpenHelper(context: Context?) : SQLiteOpenHelper(context, DATABASE_NAME, null, VERSION) {
    /**
     * Create a location table
     */
    private var createLocationTable: String? =
        "create table if not exists " + LOCATION_TABLE + "(id integer primary key autoincrement,name varchar(20),temperature varchar(20)," +
                "iconDay varchar(20),tempRange varchar(20),datetime varchar(20), self integer(20),feelsLike varchar(20),windScale varchar(20),humidity varchar(20)" +
                ",text varchar(20),lat varchar(20),lon varchar(20))"

    override fun onCreate(db: SQLiteDatabase) {
        //Perform the creation of a location information table
        db.execSQL(createLocationTable)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    companion object {
        /**
         * The name of the database
         */
        private const val DATABASE_NAME = "Weather.db"

        /**
         * Database version number
         */
        private const val VERSION = 1

        /**
         * Location information table
         */
        const val LOCATION_TABLE = "Location_tb"
    }
}