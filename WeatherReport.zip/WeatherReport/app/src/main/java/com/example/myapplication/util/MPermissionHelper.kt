package com.example.myapplication.util

import android.app.Activity
import android.app.Dialog
import android.content.DialogInterface
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.ActivityCompat
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AlertDialog
import java.util.ArrayList

/*Permission management class*/
class MPermissionHelper(private val mContext: Activity) {
    private val mPermissions: MutableList<String>
    private var setPermissionDialog: Dialog? = null
    private var goSettingsDialog: Dialog? = null

    interface PermissionCallBack {
        fun permissionRegisterSuccess(vararg permissions: String?)
        fun permissionRegisterError(vararg permissions: String?)
    }

    /**
     * Check whether a permission has been granted
     *
     * @param permissions
     * @return
     */
    private fun hasPermission(vararg permissions: String): Boolean {
        mPermissions.clear()
        for (permission in permissions) {
            val isHasthisPermission = ContextCompat.checkSelfPermission(mContext, permission)
            if (isHasthisPermission != PackageManager.PERMISSION_GRANTED) {
                mPermissions.add(permission)
            }
        }
        return mPermissions.size == 0
    }

    /**
     * Request permissions
     *
     * @param permissions
     */
    fun requestPermission(callback: PermissionCallBack, vararg permissions: String) {
        //First, determine whether the version is less than 23, and if it is less than 23, it will directly pass the permission
        var permissions = permissions
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            callback.permissionRegisterSuccess(*permissions)
            return
        }
        //If the permission is not approved, apply for the permission to be approved
        if (!hasPermission(*permissions)) {
            permissions = mPermissions.toTypedArray()
            //If no reminders are set in check, the user needs to remind them themselves
            if (!shouldShowRequestPermissions(*permissions)) {
                //Users remind themselves
                ActivityCompat.requestPermissions(
                    mContext,
                    mPermissions.toTypedArray(),
                    REQUEST_CODE_ASK_PERMISSIONS
                )
                return
            }
            ActivityCompat.requestPermissions(
                mContext,
                mPermissions.toTypedArray(),
                REQUEST_CODE_ASK_PERMISSIONS
            )
            return
        }
        //Deal with the situation after all passed
        callback.permissionRegisterSuccess()
    }

    private fun shouldShowRequestPermissions(vararg permissions: String): Boolean {
        var result = false
        for (s in permissions) {
            result = ActivityCompat.shouldShowRequestPermissionRationale(
                mContext,
                s
            )
        }
        return result
    }

    /**
     * Handle onRequestPermissionsResult
     *
     * @param requestCode
     * @param grantResults
     */
    fun handleRequestPermissionsResult(
        requestCode: Int,
        callBack: PermissionCallBack?,
        grantResults: IntArray
    ) {
        when (requestCode) {
            REQUEST_CODE_ASK_PERMISSIONS -> {
                println("requestCode = $requestCode")
                var allGranted = true
                for (grant in grantResults) {
                    if (grant != PackageManager.PERMISSION_GRANTED) {
                        allGranted = false
                        break
                    }
                }
                if (allGranted && callBack != null) {
                    callBack.permissionRegisterSuccess(*mPermissions.toTypedArray())
                } else if (!allGranted && callBack != null) {
                    callBack.permissionRegisterError(*mPermissions.toTypedArray())
                }
            }
        }
    }

    fun destroy() {
        if (setPermissionDialog != null && setPermissionDialog!!.isShowing) {
            setPermissionDialog!!.dismiss()
            setPermissionDialog = null
        }
        if (goSettingsDialog != null && goSettingsDialog!!.isShowing) {
            goSettingsDialog!!.dismiss()
            goSettingsDialog = null
        }
    }

    fun showGoSettingPermissionsDialog(showPermissionName: String) {
        goSettingsDialog = AlertDialog.Builder(mContext).setMessage(
            """
Detect that you have turned off the ${showPermissionName} permission.
    Some features may not work properly!
    In order to ensure the normal use of the function, please click Settings - > Permission Management - > to open the required permissions!
    """.trimIndent()
        )
            .setTitle("prompt")
            .setPositiveButton("Set up") { dialog, which -> goPermissionSetting() }
            .setNegativeButton("Cancel", null)
            .create()
        goSettingsDialog?.show()
    }

    fun goPermissionSetting() {
        val localIntent = Intent()
        localIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        localIntent.action = "android.settings.APPLICATION_DETAILS_SETTINGS"
        localIntent.data = Uri.fromParts("package", mContext.packageName, null)
        mContext.startActivity(localIntent)
    }

    private fun showMessageOKCancel(okListener: DialogInterface.OnClickListener) {
        setPermissionDialog = AlertDialog.Builder(mContext)
            .setMessage("Detects that you have permissions that have not been set, do you confirm that the permissions are set?")
            .setPositiveButton("OK", okListener)
            .setNegativeButton("Cancel", null)
            .create()
        setPermissionDialog?.show()
    }

    companion object {
        const val REQUEST_CODE_ASK_PERMISSIONS = 22123
    }

    init {
        mPermissions = ArrayList()
    }
}