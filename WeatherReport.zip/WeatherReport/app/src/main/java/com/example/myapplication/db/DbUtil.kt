package com.example.myapplication.db

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import com.example.myapplication.entity.Location
import com.example.myapplication.util.SpUtil.getyMdHm

/**
 * Database operation class
 */
class DbUtil {
    //Query all location information
    @SuppressLint("Range")
    fun getAllLocation(activity: Activity?): List<Location> {
        val Locations: MutableList<Location> = ArrayList()

        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase

        //Query all records from the database (using the rawQuery method), and the results obtained are represented by the cursor result set.
        val cursor =
            db.rawQuery("select * from " + DbOpenHelper.LOCATION_TABLE + " order by id desc", null)
        //Judging based on the query results
        while (cursor.moveToNext()) { //Retrieve data from the result set upon query
            val id = cursor.getInt(cursor.getColumnIndex("id"))
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val temp = cursor.getString(cursor.getColumnIndex("temperature"))
            val iconDay = cursor.getString(cursor.getColumnIndex("iconDay"))
            val tempRange = cursor.getString(cursor.getColumnIndex("tempRange"))
            val datetime = cursor.getString(cursor.getColumnIndex("datetime"))
            val self = cursor.getInt(cursor.getColumnIndex("self"))
            val feelsLike = cursor.getString(cursor.getColumnIndex("feelsLike"))
            val windScale = cursor.getString(cursor.getColumnIndex("windScale"))
            val humidity = cursor.getString(cursor.getColumnIndex("humidity"))
            val text = cursor.getString(cursor.getColumnIndex("text"))
            val lat = cursor.getString(cursor.getColumnIndex("lat"))
            val lon = cursor.getString(cursor.getColumnIndex("lon"))
            val info = Location()
            info.id = id
            info.name = name
            info.temp = temp
            info.iconDay = iconDay
            info.tempRange = tempRange
            info.datetime = datetime
            info.self = self
            info.feelsLike = feelsLike
            info.windScale = windScale
            info.humidity = humidity
            info.text = text
            info.lat = lat
            info.lon = lon
            Locations.add(info)
        }
        //deallocate
        cursor.close()
        return Locations
    }

    //Query all location information (excluding one's own location)
    @SuppressLint("Range")
    fun getAllLocationExceptSelf(activity: Activity?): MutableList<Location?> {
        val Locations: MutableList<Location?> = ArrayList()

        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase

        //Query all records from the database (using the rawQuery method), and the results obtained are represented by the cursor result set.
        val cursor = db.rawQuery(
            "select * from " + DbOpenHelper.LOCATION_TABLE + " where self=0 order by id desc",
            null
        )
        //Judging based on the query results
        while (cursor.moveToNext()) { //Retrieve data from the result set upon query
            val id = cursor.getInt(cursor.getColumnIndex("id"))
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val temp = cursor.getString(cursor.getColumnIndex("temperature"))
            val iconDay = cursor.getString(cursor.getColumnIndex("iconDay"))
            val tempRange = cursor.getString(cursor.getColumnIndex("tempRange"))
            val datetime = cursor.getString(cursor.getColumnIndex("datetime"))
            val self = cursor.getInt(cursor.getColumnIndex("self"))
            val feelsLike = cursor.getString(cursor.getColumnIndex("feelsLike"))
            val windScale = cursor.getString(cursor.getColumnIndex("windScale"))
            val humidity = cursor.getString(cursor.getColumnIndex("humidity"))
            val text = cursor.getString(cursor.getColumnIndex("text"))
            val lat = cursor.getString(cursor.getColumnIndex("lat"))
            val lon = cursor.getString(cursor.getColumnIndex("lon"))
            val info = Location()
            info.id = id
            info.name = name
            info.temp = temp
            info.iconDay = iconDay
            info.tempRange = tempRange
            info.datetime = datetime
            info.self = self
            info.feelsLike = feelsLike
            info.windScale = windScale
            info.humidity = humidity
            info.text = text
            info.lat = lat
            info.lon = lon
            Locations.add(info)
        }
        //deallocate
        cursor.close()
        return Locations
    }

    //Search location information based on name
    @SuppressLint("Range")
    fun getLocationByName(activity: Activity?, names: String): Location? {
        val Locations: MutableList<Location> = ArrayList()

        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase
        var info: Location? = null
        //Query all records from the database (using the rawQuery method), and the results obtained are represented by the cursor result set.
        val cursor = db.rawQuery(
            "select * from " + DbOpenHelper.LOCATION_TABLE + " where name=? ",
            arrayOf(names)
        )
        //Judging based on the query results
        if (cursor.moveToNext()) { //Retrieve data from the result set upon query
            val id = cursor.getInt(cursor.getColumnIndex("id"))
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val temp = cursor.getString(cursor.getColumnIndex("temperature"))
            val iconDay = cursor.getString(cursor.getColumnIndex("iconDay"))
            val tempRange = cursor.getString(cursor.getColumnIndex("tempRange"))
            val datetime = cursor.getString(cursor.getColumnIndex("datetime"))
            val self = cursor.getInt(cursor.getColumnIndex("self"))
            val feelsLike = cursor.getString(cursor.getColumnIndex("feelsLike"))
            val windScale = cursor.getString(cursor.getColumnIndex("windScale"))
            val humidity = cursor.getString(cursor.getColumnIndex("humidity"))
            val text = cursor.getString(cursor.getColumnIndex("text"))
            val lat = cursor.getString(cursor.getColumnIndex("lat"))
            val lon = cursor.getString(cursor.getColumnIndex("lon"))
            info = Location()
            info.id = id
            info.name = name
            info.temp = temp
            info.iconDay = iconDay
            info.tempRange = tempRange
            info.datetime = datetime
            info.self = self
            info.feelsLike = feelsLike
            info.windScale = windScale
            info.humidity = humidity
            info.text = text
            info.lat = lat
            info.lon = lon
            Locations.add(info)
        }
        //deallocate
        cursor.close()
        return info
    }

    //Query your own location information
    @SuppressLint("Range")
    fun getLocationBySelf(activity: Activity?): Location? {
        val Locations: MutableList<Location> = ArrayList()

        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase
        var info: Location? = null
        //Query all records from the database (using the rawQuery method), and the results obtained are represented by the cursor result set.
        val cursor = db.rawQuery(
            "select * from " + DbOpenHelper.LOCATION_TABLE + " where self=? ",
            arrayOf(1.toString() + "")
        )
        //Judging based on the query results
        if (cursor.moveToNext()) { //Retrieve data from the result set upon query
            val id = cursor.getInt(cursor.getColumnIndex("id"))
            val name = cursor.getString(cursor.getColumnIndex("name"))
            val temp = cursor.getString(cursor.getColumnIndex("temperature"))
            val iconDay = cursor.getString(cursor.getColumnIndex("iconDay"))
            val tempRange = cursor.getString(cursor.getColumnIndex("tempRange"))
            val datetime = cursor.getString(cursor.getColumnIndex("datetime"))
            val self = cursor.getInt(cursor.getColumnIndex("self"))
            val feelsLike = cursor.getString(cursor.getColumnIndex("feelsLike"))
            val windScale = cursor.getString(cursor.getColumnIndex("windScale"))
            val humidity = cursor.getString(cursor.getColumnIndex("humidity"))
            val text = cursor.getString(cursor.getColumnIndex("text"))
            val lat = cursor.getString(cursor.getColumnIndex("lat"))
            val lon = cursor.getString(cursor.getColumnIndex("lon"))
            info = Location()
            info.id = id
            info.name = name
            info.temp = temp
            info.iconDay = iconDay
            info.tempRange = tempRange
            info.datetime = datetime
            info.self = self
            info.feelsLike = feelsLike
            info.windScale = windScale
            info.humidity = humidity
            info.text = text
            info.lat = lat
            info.lon = lon
            Locations.add(info)
        }
        //deallocate
        cursor.close()
        return info
    }

    //Add location information
    @SuppressLint("Range")
    fun insertLocation(activity: Activity?, info: Location): Boolean {
        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase

        //Create an object to encapsulate a row of data
        val values = ContentValues()
        values.put("name", info.name)
        values.put("temperature", info.temp)
        values.put("iconDay", info.iconDay)
        values.put("tempRange", info.tempRange)
        values.put("datetime", getyMdHm(System.currentTimeMillis()))
        values.put("self", info.self)
        values.put("feelsLike", info.feelsLike)
        values.put("windScale", info.windScale)
        values.put("humidity", info.humidity)
        values.put("text", info.text)
        values.put("lat", info.lat)
        values.put("lon", info.lon)

        //Save the encapsulated row of data to the location of the database_ In the TABLE table
        val result = db.insert(DbOpenHelper.LOCATION_TABLE, null, values)
        return result != -1L
    }

    //Update location information
    @SuppressLint("Range")
    fun updateLocation(activity: Activity?, info: Location): Boolean {
        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase

        //Create an object to encapsulate a row of data
        val values = ContentValues()
        values.put("name", info.name)
        values.put("temperature", info.temp)
        values.put("iconDay", info.iconDay)
        values.put("tempRange", info.tempRange)
        values.put("datetime", getyMdHm(System.currentTimeMillis()))
        values.put("self", info.self)
        values.put("feelsLike", info.feelsLike)
        values.put("windScale", info.windScale)
        values.put("humidity", info.humidity)
        values.put("text", info.text)
        values.put("lat", info.lat)
        values.put("lon", info.lon)

        //Save the encapsulated row of data to the location of the database_ In the TABLE table
        val result =
            db.update(DbOpenHelper.LOCATION_TABLE, values, "id=?", arrayOf(info.id.toString())).toLong()
        return result != -1L
    }

    //Delete single location information data
    @SuppressLint("Range")
    fun deleteLocation(activity: Activity?, id: Int): Boolean {
        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase

        //Save the encapsulated row of data to the location of the database_ In the TABLE table
        val result =
            db.delete(DbOpenHelper.LOCATION_TABLE, "id=?", arrayOf(id.toString() + "")).toLong()
        return result != -1L
    }

    //Delete all location information data
    @SuppressLint("Range")
    fun deleteAllLocation(activity: Activity?): Boolean {
        //Instantiating database operation classes
        val mhelper = DbOpenHelper(activity)
        //Instantiating Database Objects
        val db = mhelper.writableDatabase

        //Save the encapsulated row of data to the location of the database_ In the TABLE table
        val result = db.delete(DbOpenHelper.LOCATION_TABLE, null, null).toLong()
        return result != -1L
    }
}