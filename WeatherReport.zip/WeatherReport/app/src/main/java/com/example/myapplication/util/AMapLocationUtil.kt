package com.example.myapplication.util

import android.content.Context
import com.amap.api.location.AMapLocationClient
import com.amap.api.location.AMapLocationClientOption
import com.amap.api.location.AMapLocationListener
import com.amap.api.location.AMapLocation
import android.util.Log
import java.lang.Exception

/*AutoNavi tools*/
class AMapLocationUtil private constructor() {
    private object Singleton {
        val sInstance = AMapLocationUtil()
    }

    fun init(context: Context, onLocationListenerCallback: OnLocationListenerCallback?) {
        listenerCallback = onLocationListenerCallback
        initLocate(context)
    }

    private var mLocationClient: AMapLocationClient? = null
    private var myLocationListener: LocationListener? = null
    private var listenerCallback: OnLocationListenerCallback? = null
    private fun initLocate(context: Context) {
        //Declare the mLocationOption object
        val mLocationOption: AMapLocationClientOption
        try {
            mLocationClient = AMapLocationClient(context)

            //Initialize the targeting parameters
            mLocationOption = AMapLocationClientOption()

            //Set up a location listener
            myLocationListener = LocationListener()
            mLocationClient!!.setLocationListener(myLocationListener)
            //Set the positioning mode to high-precision mode, Battery_Saving to low-power mode, and Device_Sensors device-only mode
            mLocationOption.locationMode = AMapLocationClientOption.AMapLocationMode.Hight_Accuracy
            //Set the positioning interval in milliseconds, the default value is 2000 ms
            mLocationOption.interval = (120 * 1000).toLong()
            mLocationOption.isOnceLocationLatest = true
            //Set targeting parameters
            mLocationClient!!.setLocationOption(mLocationOption)
            //This method will initiate a location request at a fixed time, in order to reduce power consumption or network traffic consumption.
            //Set the appropriate interval for the location time (the minimum interval is 2000ms), and call the stopLocation() method at the appropriate time to cancel the location request
            //After the positioning is over, the onDestroy() method is called at the appropriate lifecycle
            //In the case of a single location, regardless of whether the location is successful or not, there is no need to call the stopLocation() method to remove the request, and the location SDK will be removed internally
            //Start targeting
            mLocationClient!!.startLocation()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private inner class LocationListener : AMapLocationListener {
        override fun onLocationChanged(aMapLocation: AMapLocation) {
            if (aMapLocation != null) {
                if (aMapLocation.errorCode == 0) {
                    //Locate the successful callback information and set the related messages
                    Log.e(
                        "Targeting successful：",
                        "lat=" + aMapLocation.latitude + ";;lon=" + aMapLocation.longitude + ";;address=" + aMapLocation.address
                    )
                    listenerCallback!!.getLocation(
                        aMapLocation.latitude,
                        aMapLocation.longitude,
                        aMapLocation.city,
                        aMapLocation.address
                    )
                    stopLocation()
                } else {
                    //The error message ErrCode is an error code and errInfo is an error message.
                    listenerCallback!!.locationError
                    Log.e(
                        "AmapError", "location Error, ErrCode:"
                                + aMapLocation.errorCode + ", errInfo:"
                                + aMapLocation.errorInfo
                    )
                }
            }
        }
    }

    fun startLocation() {
        if (null != mLocationClient) {
            mLocationClient!!.startLocation()
        }
    }

    fun stopLocation() {
        if (null != mLocationClient) {
            mLocationClient!!.stopLocation()
        }
    }

    fun stopAndDestroyLocation() {
        if (null != mLocationClient) {
            /**
             * If AMapLocationClient is instantiated in the current Activity,
             * In the onDestroy of an activity, be sure to run the onDestroy of AMapLocationClient
             */
            mLocationClient!!.disableBackgroundLocation(true)
            mLocationClient!!.stopLocation()
            mLocationClient!!.unRegisterLocationListener(myLocationListener)
            mLocationClient!!.onDestroy()
            mLocationClient = null
        }
    }

    interface OnLocationListenerCallback {
        fun getLocation(lat: Double, lon: Double, city: String, address: String?)
        val locationError: Unit
    }

    companion object {
        fun get(): AMapLocationUtil {
            return Singleton.sInstance
        }
    }
}