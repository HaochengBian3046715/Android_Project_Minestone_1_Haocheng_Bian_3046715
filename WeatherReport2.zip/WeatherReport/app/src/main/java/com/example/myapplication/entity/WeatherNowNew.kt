package com.example.myapplication.entity

import com.example.myapplication.entity.WeatherNowNew.CurrentDTO
import com.example.myapplication.entity.WeatherNowNew.ForecastDTO
import com.example.myapplication.entity.WeatherNowNew.ForecastDTO.ForecastdayDTO
import com.example.myapplication.entity.WeatherNowNew.ForecastDTO.ForecastdayDTO.DayDTO
import com.example.myapplication.entity.WeatherNowNew.ForecastDTO.ForecastdayDTO.AstroDTO
import com.example.myapplication.entity.WeatherNowNew.ForecastDTO.ForecastdayDTO.HourDTO
import java.io.Serializable

class WeatherNowNew : Serializable {
    var location: LocationDTO? = null
    var current: CurrentDTO? = null
    var forecast: ForecastDTO? = null

    class LocationDTO : Serializable {
        var name: String? = null
        var region: String? = null
        var country: String? = null
        var lat = 0.0
        var lon = 0.0
        var tz_id: String? = null
        var localtime_epoch = 0.0
        var localtime: String? = null
    }

    class CurrentDTO : Serializable {
        var last_updated_epoch = 0.0
        var last_updated: String? = null
        var temp_c = 0.0
        var temp_f = 0.0
        var is_day = 0.0
        var condition: ConditionDTO? = null
        var wind_mph = 0.0
        var wind_kph = 0.0
        var wind_degree = 0.0
        var wind_dir: String? = null
        var pressure_mb = 0.0
        var pressure_in = 0.0
        var precip_mm = 0.0
        var precip_in = 0.0
        var humidity = 0.0
        var cloud = 0.0
        var feelslike_c = 0.0
        var feelslike_f = 0.0
        var vis_km = 0.0
        var vis_miles = 0.0
        var uv = 0.0
        var gust_mph = 0.0
        var gust_kph = 0.0

        class ConditionDTO : Serializable {
            var text: String? = null
            var icon: String? = null
            var code = 0.0
        }
    }

    class ForecastDTO : Serializable {
        var forecastday: List<ForecastdayDTO>? = null

        class ForecastdayDTO : Serializable {
            var date: String? = null
            var date_epoch = 0.0
            var day: DayDTO? = null
            var astro: AstroDTO? = null
            var hour: List<HourDTO>? = null

            class DayDTO : Serializable {
                var maxtemp_c = 0.0
                var maxtemp_f = 0.0
                var mintemp_c = 0.0
                var mintemp_f = 0.0
                var avgtemp_c = 0.0
                var avgtemp_f = 0.0
                var maxwind_mph = 0.0
                var maxwind_kph = 0.0
                    set(maxwind_kph) {
                        field = maxwind_kph
                    }
                var totalprecip_mm = 0.0
                var totalprecip_in = 0.0
                    set(totalprecip_in) {
                        field = totalprecip_in
                    }
                var totalsnow_cm = 0.0
                    set(totalsnow_cm) {
                        field = totalsnow_cm
                    }
                var avgvis_km = 0.0
                    set(avgvis_km) {
                        field = avgvis_km
                    }
                var avgvis_miles = 0.0
                    set(avgvis_miles) {
                        field = avgvis_miles
                    }
                var avghumidity = 0.0
                    set(avghumidity) {
                        field = avghumidity
                    }
                var daily_will_it_rain = 0.0
                    set(daily_will_it_rain) {
                        field = daily_will_it_rain
                    }
                var daily_chance_of_rain = 0.0
                    set(daily_chance_of_rain) {
                        field = daily_chance_of_rain
                    }
                var daily_will_it_snow = 0.0
                    set(daily_will_it_snow) {
                        field = daily_will_it_snow
                    }
                var daily_chance_of_snow = 0.0
                    set(daily_chance_of_snow) {
                        field = daily_chance_of_snow
                    }
                var condition: ConditionDTO? = null
                var uv = 0.0
                    set(uv) {
                        field = uv
                    }

                class ConditionDTO : Serializable {
                    var text: String? = null
                    var icon: String? = null
                    var code = 0.0
                }
            }

            class AstroDTO : Serializable {
                var sunrise: String? = null
                var sunset: String? = null
                var moonrise: String? = null
                var moonset: String? = null
                var moon_phase: String? = null
                var moon_illumination = 0.0
                var is_moon_up = 0.0
                var is_sun_up = 0.0
            }

            class HourDTO : Serializable {
                var time_epoch = 0.0
                var time: String? = null
                var temp_c = 0.0
                var temp_f = 0.0
                var is_day = 0.0
                var condition: ConditionDTO? = null
                var wind_mph = 0.0
                var wind_kph = 0.0
                var wind_degree = 0.0
                var wind_dir: String? = null
                var pressure_mb = 0.0
                var pressure_in = 0.0
                var precip_mm = 0.0
                var precip_in = 0.0
                var humidity = 0.0
                var cloud = 0.0
                var feelslike_c = 0.0
                var feelslike_f = 0.0
                var windchill_c = 0.0
                var windchill_f = 0.0
                var heatindex_c = 0.0
                var heatindex_f = 0.0
                var dewpoint_c = 0.0
                var dewpoint_f = 0.0
                var will_it_rain = 0.0
                var chance_of_rain = 0.0
                var will_it_snow = 0.0
                var chance_of_snow = 0.0
                var vis_km = 0.0
                var vis_miles = 0.0
                var gust_mph = 0.0
                var gust_kph = 0.0
                var uv = 0.0

                class ConditionDTO : Serializable {
                    var text: String? = null
                    var icon: String? = null
                    var code = 0.0
                }
            }
        }
    }
}