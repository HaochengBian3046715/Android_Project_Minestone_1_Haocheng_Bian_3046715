package com.example.myapplication.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.myapplication.R
import com.example.myapplication.entity.Temp

/*Weather list adapter for 24 hours today*/
class TodayTempAdapter(private val context: Context, private val mTempList: MutableList<Temp>) :
    RecyclerView.Adapter<TodayTempAdapter.ViewHolder>() {
    private var onItemClickListener: OnItemClickListener? = null

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var tv_temp: TextView
        var tv_time: TextView
        var tv_pop: TextView
        var tv_wind: TextView
        var iv_icon: ImageView
        var tv_weather: TextView

        init {
            tv_temp = itemView.findViewById(R.id.tv_temp)
            tv_time = itemView.findViewById(R.id.tv_time)
            tv_pop = itemView.findViewById(R.id.tv_pop)
            tv_wind = itemView.findViewById(R.id.tv_wind)
            iv_icon = itemView.findViewById(R.id.iv_icon)
            tv_weather = itemView.findViewById(R.id.tv_weather)
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): ViewHolder {
        val view =
            LayoutInflater.from(context).inflate(R.layout.rv_item_today_temp, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val temp = mTempList[position]
        holder.tv_time.text = temp.time
        holder.tv_temp.text = temp.temp
        holder.tv_pop.text = String.format("%s", temp.prec)
        holder.tv_wind.text = temp.wind
        holder.tv_weather.text = temp.text

        holder.itemView.setOnClickListener {
            if (onItemClickListener != null) {
                onItemClickListener!!.onContentClick(temp, holder.adapterPosition)
            }
        }
    }

    override fun getItemCount(): Int {
        return mTempList.size
    }

    fun update(tempList: List<Temp>?) {
        mTempList.clear()
        mTempList.addAll(tempList!!)
        notifyDataSetChanged()
    }

    interface OnItemClickListener {
        fun onContentClick(temp: Temp?, position: Int)
    }

    fun setOnItemClickListener(onItemClickListener: OnItemClickListener?) {
        this.onItemClickListener = onItemClickListener
    }
}